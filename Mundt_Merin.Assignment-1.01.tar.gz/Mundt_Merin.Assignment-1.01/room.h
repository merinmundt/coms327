

typedef	struct room {
	
		int x;
		int y; 
		int w; 
		int h;
	}Room;

